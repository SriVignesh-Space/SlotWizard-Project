import React from 'react'

const ErrorEl = () => {
  return (
    <div>ErrorEl</div>
  )
}

export default ErrorEl